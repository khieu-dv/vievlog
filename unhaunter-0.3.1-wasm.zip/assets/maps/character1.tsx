<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="CH1" tilewidth="32" tileheight="32" tilecount="64" columns="16">
 <image source="../img/characters-model1-demo.png" width="512" height="128"/>
</tileset>
