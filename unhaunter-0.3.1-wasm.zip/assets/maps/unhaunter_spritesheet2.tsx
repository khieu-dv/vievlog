<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="S2" tilewidth="77" tileheight="77" spacing="3" margin="2" tilecount="144" columns="12" objectalignment="bottom">
 <tileoffset x="-24" y="12"/>
 <grid orientation="isometric" width="72" height="36"/>
 <properties>
  <property name="Anchor::bottom_px" type="int" value="19"/>
 </properties>
 <image source="../img/spritesheet2.png" width="960" height="960"/>
 <tile id="0">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="8" width="24" height="28"/>
  </objectgroup>
 </tile>
</tileset>
