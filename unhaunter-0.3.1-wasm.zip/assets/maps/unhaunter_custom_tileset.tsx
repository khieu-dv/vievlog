<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="CUSTOM" tilewidth="162" tileheight="132" tilecount="1" columns="0" objectalignment="bottom">
 <tileoffset x="-67" y="27"/>
 <grid orientation="orthogonal" width="512" height="36"/>
 <tile id="0" type="Van">
  <properties>
   <property name="sprite:orientation" value="XAxis"/>
   <property name="sprite:state" value="None"/>
   <property name="sprite:variant" value="Base"/>
  </properties>
  <image width="162" height="132" source="../img/van.png"/>
  <objectgroup draworder="index" id="2">
   <object id="9" x="80" y="13">
    <polygon points="0,0 -74,57 7,106 62,78"/>
   </object>
  </objectgroup>
 </tile>
</tileset>
