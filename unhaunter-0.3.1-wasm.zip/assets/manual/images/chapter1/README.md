Images for this folder:

* Investigate: assets/manual/images/chapter1/investigate.png - Image of the player exploring a room, using a flashlight.

* Locate Ghost: assets/manual/images/chapter1/locate_ghost.png - Image of the ghost's breach (spawn point).

* Identify Ghost: assets/manual/images/chapter1/identify_ghost.png - Image of the truck journal with evidence highlighted.

* Craft Repellent: assets/manual/images/chapter1/craft_repellent.png - Image of the repellent crafting interface in the truck.

* Expel Ghost: assets/manual/images/chapter1/expel_ghost.png - Image of the player using the repellent on the ghost.

* End Mission: assets/manual/images/chapter1/end_mission.png - Image of the "End Mission" button in the truck.


