

import React from "react";
import { Emitter } from "./components/Emitter";

export const PhotoGallery: React.FC = () => {
    return (
        <>
            <Emitter />
        </>
    );
};
