import { TwoFactorPageClient } from "./client";

export default function TwoFactorPage() {
  return <TwoFactorPageClient />;
}
