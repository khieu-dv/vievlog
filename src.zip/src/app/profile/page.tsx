import { ProfilePageClient } from "./client";

export default function ProfilePage() {
  return <ProfilePageClient />;
}
